/** @class MonitorLedClassObject */
class MonitorLedClassObject {
    background_color;
    text_align;
    margin_top;
    color;
    constructor() {
        this.background_color = "lightyellow";
        this.text_align = "left";
        this.margin_top = "2px";
        this.color = "black";
    }
}
