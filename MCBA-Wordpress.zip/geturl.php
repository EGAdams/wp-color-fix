<?php
defined('ABSPATH') || exit;
echo $_SERVER['REQUEST_URI'];
?>