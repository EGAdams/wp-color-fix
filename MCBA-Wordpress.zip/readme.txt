=== My Custom Business App ===
Contributors: awm00101dev3
Donate link: https://mycustombusinessapp.com/
Tags: comments, spam
Requires at least: 4.7
Tested up to: 5.5.3
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This plugin lets you build your own custom application in WordPress that works with iOS and Android devices.

*   "Tags" is a comma separated list of tags that apply to the plugin


== Frequently Asked Questions ==
(352) 556-3926

== Screenshots ==

1. No screenshots in notepad!

== Changelog ==
= 2.4.2002 =
* conformed to latest WordPress guidelines as of October of 2020.

== Upgrade Notice ==

= 2.4.20026 =
* conformed to latest WordPress guidelines in January of 2021.

= 2.4.20027 =
* fixed communication bugs caused by bad AJAX calls.

== A brief Markdown ==
1. Chat room
2. Rewards
3. Map
