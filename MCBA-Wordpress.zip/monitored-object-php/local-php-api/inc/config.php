<?php
define( "MO_DB_HOST",          'americansjewelry.com'           );
define( "MO_DB_USERNAME",      'tinman72_4a4e_cg'               );
define( "MO_DB_PASSWORD",      'th3RIver0fL1F3Data$toraGePl@ce' );
define( "MO_DB_DATABASE_NAME", 'tinman72_rest_api_demo'         ); 