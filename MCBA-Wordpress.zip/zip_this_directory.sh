#
# may 3 first friday 2024
#
zip -r MCBA-Wordpress.zip . -x '*.git*' '*.vscode*' '*a_sandbox*' '*inc/phpqrcode*' '*mcbaMasterKeyDoNotDeleteEver*'



