
// open firebase console and inspect
// select maximum amount of rows shown
// paste the meat of the code above into the console
// the document ready doesn't seem to be working, so just paste
// manually until i figure out wtf is wrong.

$( document ).ready( function() {

    $( '.edit-account-button.mat-focus-indicator.mat-menu-trigger.mat-tooltip-trigger.mat-icon-button.mat-button-base' ).click()
    $( '.mat-focus-indicator.mat-menu-item.ng-star-inserted:contains(Delete)' ).click()
    $( '.confirm-button.mat-focus-indicator.mat-raised-button.mat-button-base.mat-warn' ).click()

});


