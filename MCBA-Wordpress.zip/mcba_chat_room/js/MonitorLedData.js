/** @class MonitorLedData */

class MonitorLedData {
    constructor() {
        this.classObject = new MonitorLedClassObject();
        this.ledText     = "ready.";
    }

}