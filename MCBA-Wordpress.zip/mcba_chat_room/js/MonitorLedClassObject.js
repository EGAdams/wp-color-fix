/** @class MonitorLedClassObject */

class MonitorLedClassObject {
    constructor() { 
        this.background_color = "lightyellow";
        this.text_align       = "left";
        this.margin_top       = "2px";
        this.color            = "black"; }
}
