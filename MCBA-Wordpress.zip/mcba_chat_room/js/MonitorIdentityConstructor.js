/*
 * class MonitorIdentityConstructor
 */

class MonitorIdentityConstructor {

    constructor() {
        throw( "not implemented." );
    }
}
