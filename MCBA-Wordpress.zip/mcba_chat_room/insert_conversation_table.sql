insert into
    wp_mcba_chat_conversations
set
    conversation_id = '190',
    user = 'steve@gmail.com',
    admin = 'expert@',
    admin_unread_messages = '0',
    user_unread_messages = '0',
    mcba_chat_system_id = 'steve@gmail.com';

    